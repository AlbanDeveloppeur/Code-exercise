const lotoResultDiv = document.createElement("div");
const main = document.querySelector("main");

export function displayLotoNumber(lotoNumber) {
	lotoResultDiv.id = "loto-result";
	main.append(lotoResultDiv);

	lotoNumber.lotoNumberArray.forEach((number) => {
		createLotoBoule(number);
	});

	createLotoBoule(lotoNumber.lotoJoker, true);
}

function createLotoBoule(number, joker = false) {
	let displayLotoNumberBox = document.createElement("div");
	displayLotoNumberBox.classList.add("loto-number-box");

	let lotoBouleNumber = document.createElement("img");
	lotoBouleNumber.src = joker ? "img/joker.png" : "img/boule.png";
	displayLotoNumberBox.append(lotoBouleNumber);

	let lotoNumberDiv = document.createElement("div");
	displayLotoNumberBox.append(lotoNumberDiv);

	let lotoNumberSpan = document.createElement("span");
	lotoNumberSpan.textContent = number;
	lotoNumberDiv.append(lotoNumberSpan);

	lotoResultDiv.append(displayLotoNumberBox);
}
