export function reset() {
    const messageLotoDiv = document.querySelector("#loto-message");
    const resultLotoDiv = document.querySelector("#loto-result");
    const formLoto = document.querySelector("#loto-player-form");

    messageLotoDiv.remove();
    resultLotoDiv.remove();
    formLoto.reset();
}