export function numberComparison(playerNumber, lotoArray) {
    let goodNumber = 0;
    
    lotoArray["lotoNumberArray"].forEach((number) => {
        if (playerNumber.playerLotoNumber.includes(number)) {
            goodNumber++;
        }
    });

    if (lotoArray.lotoJoker == playerNumber.playerLotoJoker) {
        goodNumber++;
    }

    return goodNumber;
}