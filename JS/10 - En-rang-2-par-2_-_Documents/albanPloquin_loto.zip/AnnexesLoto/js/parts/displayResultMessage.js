export function displayResultMessage(goodNumber) {
    let message;

    switch (goodNumber) {
        case 0:
            message = "0 chiffre bon ?";
            break;
    
        case 1:
            message = "1 chiffre bon !";
            break;

        case 6:
            message = "Tout est bon !";
            break;

        default:
            message = goodNumber + " chiffres bon, retente ta chance !";
            break;
    }

    const main = document.querySelector("main");

    let p = document.createElement("p");
    p.id = "loto-message";
    p.textContent = message;
    main.append(p);
}
