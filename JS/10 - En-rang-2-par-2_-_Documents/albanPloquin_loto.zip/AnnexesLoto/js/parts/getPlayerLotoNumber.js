export function getPlayerLotoNumber() {
    let lotoNumberInputArray = document.querySelectorAll("#loto-player-form input.player-loto-number"),
        playerLotoNumberArray = [];

    lotoNumberInputArray.forEach(element => {
        if (element.value && element.value < 50 && !playerLotoNumberArray.includes(element.value)) {
            playerLotoNumberArray.push(Number(element.value));
        }
    });

    let playerLotoJokerInput = document.querySelector("#loto-player-form input.player-loto-joker");
    let playerLotoJoker = null;

    if (playerLotoJokerInput.value && playerLotoJokerInput.value < 10) {
        playerLotoJoker = Number(playerLotoJokerInput.value);
    }

    return {
        "playerLotoNumber": playerLotoNumberArray,
        "playerLotoJoker": playerLotoJoker
    };
}