export function generateLotoNumber() {
    let lotoNumber = [];

    while (lotoNumber.length < 5) {
        let randomNumber = Math.floor(Math.random() * 49);
        if (!lotoNumber.includes(randomNumber)) {
            lotoNumber.push(randomNumber);
        }
    }

    let randomStarNumber = Math.floor(Math.random() * 9);

    return {
        "lotoNumberArray": lotoNumber,
        "lotoJoker": randomStarNumber
    };
}