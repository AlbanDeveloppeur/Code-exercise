import { getPlayerLotoNumber }      from "./parts/getPlayerLotoNumber.js";
import { generateLotoNumber }       from "./parts/generateLotoNumber.js";
import { numberComparison }         from "./parts/numberComparison.js";
import { displayLotoNumber }        from "./parts/displayLotoNumber.js";
import { displayResultMessage }     from "./parts/displayResultMessage.js";
import { reset }                    from "./parts/reset.js";

const playButton = document.querySelector("#joue");
const resetButton = document.querySelector("#rejouer");

playButton.addEventListener("click", function(e) {
    e.preventDefault();
    let error = false;
    let errorText = document.querySelector("#error");
    
    errorText.classList.add("d-none");

    let lotoArray = generateLotoNumber();
    let playerLotoArray = getPlayerLotoNumber();

    if (playerLotoArray.playerLotoNumber.length < 5 || playerLotoArray.playerLotoJoker === null) {
        errorText.classList.remove("d-none");
        error = true;
    }

    if (!error) {
        playButton.toggleAttribute("disabled");
        resetButton.toggleAttribute("disabled");

        let goodNumber = numberComparison(playerLotoArray, lotoArray);
        
        const main = document.querySelector('main');
        main.classList.add("justify-content-between");
    
        displayResultMessage(goodNumber);
        displayLotoNumber(lotoArray);
    }
});

resetButton.addEventListener("click", function(e) {
    e.preventDefault();

    playButton.toggleAttribute("disabled");
    resetButton.toggleAttribute("disabled");

    reset();
})