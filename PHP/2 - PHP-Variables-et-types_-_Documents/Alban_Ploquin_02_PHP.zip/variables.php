<?php

/* Partie 1 */

$number1 = 10;
$number2 = 4;
$message = 'Le résultat de la division vaut : ';
$result = $number1 / $number2;

echo $message . $result . '<br>';

/* Partie 2 */

$isTrue = true;
$isFalse = !$isTrue;
$message = 'La variable booléenne "isFalse" vaut : ';

echo $message . ($isFalse ? 'true' : 'false') . '<br>';

/* Partie 3 */

$number3 = 4.56713;
$otherResult = $number3 * $number2;
$message = 'Le résultat de la multiplication vaut : ' . $otherResult;

echo $message;
echo '<br>';

/* SUITE : à vous de jouer */

$trueOrFalse = $isTrue && $isFalse;
$message = 'La variable booléenne "trueOrFalse" vaut : ';

echo $message . ($trueOrFalse ? "true" : "false") . "<br>";

$trueOrFalse = $isTrue || $isFalse;
$message = 'La variable booléenne "trueOrFalse" vaut : ';

echo $message . ($trueOrFalse ? "true" : "false") . "<br>";

$nom = "Pomelo";
$prenom = "Bertrand";

echo ("Bonjour " . $prenom . " " . $nom . ", comment allez-vous ?");

?>