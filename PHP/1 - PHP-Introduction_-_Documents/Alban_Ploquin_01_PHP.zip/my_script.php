<?php

echo (
    "Un premier script en PHP !\n
    Version de PHP installée : " . phpversion()
);

?>