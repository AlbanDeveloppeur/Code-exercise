<?php

$gameOver = true;
$score = 1789;
$highScore = 1492;

if (!$gameOver && ($score > $highScore)) {
    echo 'Vous êtes le meilleur !';
} else if (!$gameOver && ($score <= $highScore)) {
    echo 'Encore un effort !';
} else {
    echo 'Vous avez perdu !';
}

echo ("<br><br>");

for ($i = 10; $i >= 0; $i -= 2) { 
    echo ("i vaut : " . $i . "<br>");
}

$price = [1, 45, 4.235, 4, 8];
echo ('<br>Taille du tableau $price : ' . count($price) . "<br>");

echo ("<br>");

for ($i = 0; $i < count($price); $i++) { 
    echo ("Valeur de l'index " . $i . ' du tableau $price : ' . $price[$i] . "<br>");
}

echo ("<br>");

$price[2] = $price[2] * 156 / 0.256;
$amount = 0;

for ($i = 0; $i < count($price); $i++) {
    if ($price[$i] > 4) {
        $amount += $price[$i];
        
        echo ("Valeur de l'index " . $i . ' du tableau $price supérieur à 4 : ' . $price[$i] . "<br>");
    }
}

echo ("<br>Montant total : " . $amount)

?>