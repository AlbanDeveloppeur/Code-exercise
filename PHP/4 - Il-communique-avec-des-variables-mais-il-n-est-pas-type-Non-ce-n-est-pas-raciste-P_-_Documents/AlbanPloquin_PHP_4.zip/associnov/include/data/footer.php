<footer>
    <div>
        <p>Assoc'Inov</p>
        <p>32 Cours de l'Antre - 99966 IVRY SUR COURS</p>
    </div>

    <div class="social-container">
        <a href="contact.php">Contact</a>
        <a href="#">Plans</a>
    </div>
</footer>