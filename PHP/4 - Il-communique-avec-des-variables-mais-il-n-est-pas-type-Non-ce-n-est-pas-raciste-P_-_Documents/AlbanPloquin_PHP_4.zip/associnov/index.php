<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Assoc'Inov</title>
        <link rel="stylesheet" href="include/css/styles.css">
    </head>
    <body>
        <?php
            include_once("include/data/header.php")
        ?>

        <?php
            include_once("include/data/nav.php")
        ?>

        <main>
            <h2>Page d'accueil</h2>

            <p>
                1. Les Variables valide sont : $a - $_a - $a_a - $a1
            </p>
            <p>
                <?php 
                    $note_maths = 15;
                    $note_francais = 12;
                    $note_histoire_geo = 9;
                    $moyenne = ($note_maths + $note_francais + $note_histoire_geo) / 3;

                    echo '2. La moyenne est de'  . $moyenne . '/20';
                ?>
            </p>
            <p>
                <?php
                    $prix_ht = 50;
                    $tva = 20;
                    $prix_ttc = $prix_ht + ($prix_ht * ($tva / 100));

                    echo '3. Le prix TTC du produit est de ' . $prix_ttc . ' €.';
                ?>
            </p>
            <p>
                <?php
                    echo '4. Le résultat du var_dump() de $test :';
                    $test = "42";
                    echo var_dump($test);
                ?>
            </p>
            <p>
                5. 
                <?php 
                    $a = "Les ";
                    // La variable $a enverra une chaine de caractères contenant "Les "
                    echo nl2br($a . "\n");

                    $b = "7 merveilles du monde";
                    // La variable $b enverra aussi une chaine de caractères mais contenant "7 merveilles du monde"
                    echo nl2br($b . "\n");

                    $c = $a . $b;
                    // La variable $c sera la concaténation des variables $a et $b, et contiendra "Les 7 merveilles du mondes"
                    echo nl2br($c . "\n");

                    $d = $b + 13;
                    // La variable $d enverra une erreur car on essaie d'ajouter à une chaine de caractère un nombre, ce qui est impossible. Cependant l'addition de 7 + 13 se fera
                    echo nl2br($d . "\n");

                    $b = &$c;
                    // L'opérateur "&" a été associé aux variables $b et $b. Dorénavant, si la variable $c change dans le script, $b prendra automatiquement la même valeur. Ici il affichera "Les 7 merveilles du monde"
                    echo nl2br($b . "\n");
                ?>
            </p>
            <p>
                6.
                <?php
                    $x = "3 fois";
                    echo nl2br('$x affichera "3 fois" et sera de type string' . "\n");

                    $x *= 5.2;
                    echo nl2br('$x enverra une erreur parce qu\'on essaie de multiplier un string et un int, mais le résultat de (3 * 5.2) sera affiché. La valeur sera de type float' . "\n");

                    $z = $x % 5;
                    echo nl2br('$z affichera 0 et sera de type int' . "\n");

                    $x = "0" || 1;
                    echo nl2br('$x étant considéré comme de type int, ici la valeur de $x sera 1, est de type int' . "\n");

                    $y = is_string($x);
                    echo nl2br('$x n\'étant de type string mais int, $y affichera false, et sera de type boolean' . "\n");
                ?>
            </p>
            <p>
                <?php
                    $php_info = $_SERVER['SERVER_SIGNATURE'];
                    $php_os = $_SERVER['SystemRoot'];
                    $php_folder = $_SERVER['DOCUMENT_ROOT'];
                    $php_host = $_SERVER['HTTP_HOST'];
                    $php_lang = $_SERVER['HTTP_ACCEPT_LANGUAGE'];

                    echo nl2br('7. La version de php : ' . $php_info),
                        nl2br('Le système d\'exploitation du serveur : ' . $php_os . "\n"),
                        nl2br('Le fichier courant : ' . $php_folder . "\n"),
                        nl2br('Le HOST : ' . $php_host . "\n"),
                        nl2br('La langue du navigateur : ' . $php_lang . "\n");
                ?>
            </p>
            <p>
                <?php
                    $months = array("Janvier", "Février", "Mars", "Avril", "Mai", "Juin", "Juillet", "Août", "Septembre", "Octobre", "Novembre", "Décembre");
                    $number_months = count($months);

                    echo '8. Le nombre de mois dans une année : ' . $number_months;
                ?>
            </p>
            <p>
                <?php
                    $months_english = array(
                        "Janvier" => "January",
                        "Février" => "February",
                        "Mars" => "March",
                        "Avril" => "April",
                        "Mai" => "May",
                        "Juin" => "June",
                        "Juillet" => "July",
                        "Août" => "August",
                        "Septembre" => "September",
                        "Octobre" => "October",
                        "Novembre" => "November",
                        "Décembre" => "December"
                    );

                    // Print n'affichera que le type de la variable, et affichera une erreur pour annoncer conversion d'un type array vers string impossible
                    echo('9. ');
                    print($months_english);
                    // Echo affichera la meme chose que pour "print"
                    echo($months_english);
                    // Print_r affichera le tableau en ligne
                    print_r($months_english);
                    // Var_dump affichera le tableau en colonne de façon plus détaillé que print_r
                    var_dump($months_english);
                ?>
            </p>
            <p>
                <?php
                    echo('10. ');
                    print_r($months_english[$months['1']]);
                    print(' - ');
                    print_r($months_english[$months['3']]);
                    print(' - ');
                    print_r($months_english[$months['4']]);
                    print(' - ');
                    print_r($months_english[$months['9']]);
                ?>
            </p>
            <p>
                <?php
                    $array = [
                        0 => [
                            "id" => 1,
                            "Titre" => "Overwatch",
                            "Date" => "17/07/2022",
                            "Durée" => "48 heures",
                            "Lieu" => "Pessac"
                        ],
                        1 => [
                            "id" => 1,
                            "Titre" => "Apex",
                            "Date" => "27/07/2022",
                            "Durée" => "24 heures",
                            "Lieu" => "Merignac"
                        ],
                        2 => [
                            "id" => 1,
                            "Titre" => "World Of Warcraft",
                            "Date" => "05/08/2022",
                            "Durée" => "60 heures",
                            "Lieu" => "Bordeaux"
                        ],
                        3 => [
                            "id" => 1,
                            "Titre" => "Fall Guys",
                            "Date" => "09/08/2022",
                            "Durée" => "5 heures",
                            "Lieu" => "Saint Jean d'Angély"
                        ]
                    ];
                ?>
            </p>
        </main>

        <?php
            include_once("include/data/footer.php")
        ?>
    </body>
</html>