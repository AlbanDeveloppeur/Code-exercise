<?php

echo '<h1>PHP et HTML</h1>';

/******************************
 *     Partie 1
 ******************************/

$message = '... à partir d\'ici';

/******************************
 *     Partie 2
 ******************************/

$firstname = 'John';
$lastname = 'Doe';
$age = 38;

$string1 = 'My name is ' . $firstname . ' ' . $lastname . '!';
$string2 = "My name is $firstname $lastname!";
$string3 = "My name is <em>$firstname $lastname</em>!";

echo $string1 . '<br>';
print $string1 . '<br>';
echo $string2 . '<br>';
echo '<strong>', $string3, '</strong>', '<br>';

/******************************
 *     Partie 3
 ******************************/

$customerData = [
    'firstname' => 'John',
    'lastname' => 'Doe',
    'age' => 38,
];

$string4 = "Name : %s %s / Age : %d<br>";
printf($string4, $firstname, $lastname, $age);
vprintf($string4, $customerData);

/******************************
 *     Partie 4
 ******************************/

echo '<ul>';
for ($i = 0; $i < 10; $i++) {
    echo '<li>Item numéro ' . ($i + 1) . '</li>';
}
echo '</ul>';

?>

<!--
******************************
*     Partie 5
******************************
-->

<h2><?php echo "À vous de jouer..."; ?></h2>
<h3><?= $message ?></h3>

<?php

echo "<h1>Texte dans une balise heading de niveau 1 (h1)</h1>";
echo "<b>Texte affiché en gras</b>";

/* SUITE : à vous de jouer */

echo "<h3>Mon titre H3 écris avec 'echo' en PHP</h3>",
    "<p><em><b>Ma phrase en gras et italique</b></em></p>",
    "<p style='color: red'>Une phrase écris en rouge.</p>",
    "<p>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Iure provident veniam repellendus fugiat repudiandae, error beatae dignissimos alias, minima, praesentium quidem laudantium eos quaerat fugit.</p>",
    "<p>Voici <b>une phrase</b> que j'ai <em>écrite</em> de <h2>moi même</h2></p>";

?>

<style>
    table,
    td {
        border: 1px solid #333;
    }
</style>

<table>
    <?php for ($i = 1; $i <= 10; $i++) { ?>
        <tr>
            <?php for ($z = 1; $z <= 10; $z++) {
                echo "<td>Ligne $i, Cellule $z</td>";
            } ?>
        </tr>
    <?php } ?>
</table>
