<?php

$products = [
    [
        'id' => 27,
        'name' => 'Bonnet',
        'title' => 'Bonnet en laine d\'agneau.',
        'price' => 9.9
    ],
    [
        'id' => 34,
        'name' => 'Echarpe',
        'title' => 'Echarpe en laine de mouton.',
        'price' => 19.5
    ],
    [
        'id' => 122,
        'name' => 'Blouson',
        'title' => 'Blouson 50% polyester / 50% laine d\'alpaga.',
        'price' => 19.5
    ],
];

?>

<style>
    table {
        margin: 1rem
    }

    table,
    td {
        border: 1px solid #333;
    }
</style>

<?php

for ($i = 0; $i < count($products); $i++) {
    echo "<table>",
            "<tbody>";
            for ($z = 0; $z < count($products[$i]); $z++) {
                $arrayKey = array_keys($products[$i])[$z];
    echo        "<tr>",
                    "<td>$arrayKey</td>",
                    "<td>" . $products[$i][$arrayKey] . "</td>",
                "</tr>";
            }   
    echo    "</tbody>",
        "</table>";
}

?>