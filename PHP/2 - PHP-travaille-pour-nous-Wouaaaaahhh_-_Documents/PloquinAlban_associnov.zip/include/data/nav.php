<nav>
    <ul>
        <a href="index.php">
            <li class="selected">Accueil</li>
        </a>
        <a href="adherents.php">
            <li>Adhérents</li>
        </a>
        <a href="activite.php">
            <li>Activités</li>
        </a>
        <a href="animateurs.php">
            <li>Animateurs</li>
        </a>
        <a href="actualites.php">
            <li>Actualités</li>
        </a>
    </ul>
</nav>