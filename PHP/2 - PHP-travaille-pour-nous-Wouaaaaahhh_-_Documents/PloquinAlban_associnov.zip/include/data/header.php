<header>
    <div id="logo"></div>
    <h1>assoc'inov</h1>
    <span>L'association de l'innovation</span>
</header>