<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact - Confirmation</title>
    <link rel="stylesheet" href="./assets/css/style.css" />
</head>

<body>
    <section>
        <h1>Confirmation de l'envoie du message</h1>
        <article>
            <?php

            $fieldsArray = [
                "email" => "Email",
                "subject" => "Sujet",
                "message" => "Message",
            ];

            foreach ($fieldsArray as $key => $field) {
                if (empty($_GET[$key])) {
                    $errorArray[] = $key;
                }
            }

            if (!empty($errorArray)) {
                $message = "<p>Erreur ! Ces champs du formulaire sont vide :</p>";
                
                foreach ($errorArray as $errorField) {
                    $message .= "<p>" . $fieldsArray[$errorField] . "</p>";
                }

                echo $message;
            } else {
                $date = date("d F Y - h:i:s");
                $from = empty($_GET["identity"]) ? $_GET["email"] : $_GET["email"] . " (" . $_GET["identity"] . ")";
                $subject = $_GET["subject"];
                $message = $_GET["message"];

                echo "<ul>",
                        "<li><b>Reçu le</b> : " . $date . "</li>",
                        "<li><b>De</b> : " . $from . "</li>",
                        "<li><b>Sujet</b> : " . $subject . "</li>",
                        "<li><b>Message</b> : " . $message . "</li>",
                    "</ul>";
            }

            ?>
            <p><a href="contact_form.php" title="Retour au formulaire">Retour au formulaire</a></p>
        </article>
    </section>
</body>
