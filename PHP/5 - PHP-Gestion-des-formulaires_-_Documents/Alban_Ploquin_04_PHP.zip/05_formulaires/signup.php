<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription - Confirmation</title>
    <link rel="stylesheet" href="./assets/css/style.css" />
</head>

<body>
    <section>
        <h1>Confirmation de l'inscription</h1>
        <article>
            <?php

            $fieldsArray = [
                "lastname" => "Nom",
                "firstname" => "Prénom",
                "email" => "Email"
            ];

            foreach ($_GET as $key => $field) {
                if (empty($field)) {
                    $errorArray[] = $key;
                }
            }

            if (!empty($errorArray)) {
                $message = "<p>Erreur ! Ces champs du formulaire sont vide :</p>";
                
                foreach ($errorArray as $errorField) {
                    $message .= "<p>" . $fieldsArray[$errorField] . "</p>";
                }

                echo $message;
            } else {
                $nom = $_GET['lastname'];
                $prenom = $_GET['firstname'];
                $email = $_GET['email'];

                echo "<p>Bonjour " . $prenom . " " . $nom . ". Votre e-mail : " . $email . "</p>";
            }

            ?>
            <p><a href="signup_form.php" title="Retour au formulaire">Retour au formulaire</a></p>
        </article>
    </section>
</body>
