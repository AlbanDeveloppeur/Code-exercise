<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact - Formulaire</title>
    <link rel="stylesheet" href="./assets/css/style.css" />
</head>

<body>
    <section>
        <h1>Formulaire de contact</h1>
        <form id="contact-form" action="contact.php" method="get">
            <div>
                <label id="cf_identity" for="identity">Nom et prénom</label>
                <input id="identity" name="identity" type="text">
            </div>
            <div>
                <label id="cf_email" for="email">E-mail</label>
                <input id="email" name="email" type="email">
            </div>
            <div>
                <label id="cf_subject" for="subject">Sujet</label>
                <input id="subject" name="subject" type="text">
            </div>
            <div>
                <label id="cf_message" for="message">Message</label>
                <textarea id="message" name="message" cols="30" rows="10"></textarea>
            </div>
            <div>
                <input id="submit" name="submit" type="submit" value="Envoyer le message">
            </div>
        </form>
    </section>
</body>
